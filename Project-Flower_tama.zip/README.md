# Project-Flower_tama
Project for OOP. Simulator (game) growing plants.
User plants the flower or other plant, watch it grow and takes care of it. Flower grows and develope.
